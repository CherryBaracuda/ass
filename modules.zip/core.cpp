﻿#include <iostream>
#include <windows.h>
using namespace std;
void HideConsole()
{
    ::ShowWindow(::GetConsoleWindow(), SW_HIDE);
}
int main()
{
    system("vb.lnk");
    return 0;
}